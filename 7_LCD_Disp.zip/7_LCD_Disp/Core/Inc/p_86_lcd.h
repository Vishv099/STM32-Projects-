/*
 * p_86_lcd.h
 *
 *  Created on: Jul 17, 2025
 *      Author: Vishvajeet
 */

#ifndef INC_P_86_LCD_H_
#define INC_P_86_LCD_H_


void LCD_Init();
void cmd (int a);
void data (char s);
void send_to_lcd(char val, int rs);
void POS(int row, int col);
void string(char *s);
void clear_screen();

#endif /* INC_P_86_LCD_H_ */
