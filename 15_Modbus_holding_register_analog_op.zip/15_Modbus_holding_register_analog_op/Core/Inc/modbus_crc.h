/*
 * modbus_crc.h
 *
 *  Created on: Sep 20, 2025
 *      Author: Vishvajeet
 */

#ifndef INC_MODBUS_CRC_H_
#define INC_MODBUS_CRC_H_
/*#ifdef modbus_crc
#define modbus_crc*/

uint16_t crc16(uint8_t *buffer, uint16_t buffer_lenght);

#endif /* INC_MODBUS_CRC_H_ */
