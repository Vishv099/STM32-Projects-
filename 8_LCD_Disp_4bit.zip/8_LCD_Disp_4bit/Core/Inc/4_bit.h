/*
 * 4_bit.h
 *
 *  Created on: Jul 18, 2025
 *      Author: Vishvajeet
 */

#ifndef INC_4_BIT_H_
#define INC_4_BIT_H_

void pulse_enable();
void write_4_bits(uint8_t data);
void send_to_lcd(uint8_t val, uint8_t rs);
void cmd(uint8_t cmd_val);
void data(uint8_t data_val);
void LCD_Init();
void POS(int row, int col);
void string(char *str);
void clear_screen();

#endif /* INC_4_BIT_H_ */
