#include "stm32f1xx_hal.h"
#include "4_bit.h"

#define RS_PIN GPIO_PIN_8
#define E_PIN  GPIO_PIN_9

#define D4_PIN GPIO_PIN_4
#define D5_PIN GPIO_PIN_5
#define D6_PIN GPIO_PIN_6
#define D7_PIN GPIO_PIN_7

#define LCD_GPIO_PORT GPIOA

void pulse_enable()
{
    HAL_GPIO_WritePin(LCD_GPIO_PORT, E_PIN, GPIO_PIN_SET);
    HAL_Delay(1);  // Small delay
    HAL_GPIO_WritePin(LCD_GPIO_PORT, E_PIN, GPIO_PIN_RESET);
    HAL_Delay(1);
}

void write_4_bits(uint8_t data)
{
    HAL_GPIO_WritePin(LCD_GPIO_PORT, D4_PIN, (data >> 0) & 0x01);
    HAL_GPIO_WritePin(LCD_GPIO_PORT, D5_PIN, (data >> 1) & 0x01);
    HAL_GPIO_WritePin(LCD_GPIO_PORT, D6_PIN, (data >> 2) & 0x01);
    HAL_GPIO_WritePin(LCD_GPIO_PORT, D7_PIN, (data >> 3) & 0x01);

    pulse_enable();
}

void send_to_lcd(uint8_t val, uint8_t rs)
{
    HAL_GPIO_WritePin(LCD_GPIO_PORT, RS_PIN, rs ? GPIO_PIN_SET : GPIO_PIN_RESET);

    write_4_bits(val >> 4);     // Send upper nibble
    write_4_bits(val & 0x0F);   // Send lower nibble

    HAL_Delay(2);
}

void cmd(uint8_t cmd_val)
{
    send_to_lcd(cmd_val, 0);
}

void data(uint8_t data_val)
{
    send_to_lcd(data_val, 1);
}

void LCD_Init()
{
    HAL_Delay(50);  // LCD Power ON delay

    cmd(0x33);  // Initialization sequence
    cmd(0x32);  // Set to 4-bit mode
    cmd(0x28);  // 4-bit, 2 line, 5x8 font
    cmd(0x0E);  // Display ON, cursor ON
    cmd(0x06);  // Increment cursor
    cmd(0x01);  // Clear display
    HAL_Delay(2);
}

void POS(int row, int col)
{
    switch (row)
    {
    case 1:
        cmd(0x80 + (col - 1));
        break;
    case 2:
        cmd(0xC0 + (col - 1));
        break;
    }
}

void string(char *str)
{
    while (*str)
        data(*str++);
}

void clear_screen()
{
    cmd(0x01);
    HAL_Delay(2);
}
