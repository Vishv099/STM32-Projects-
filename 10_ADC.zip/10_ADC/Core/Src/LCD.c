/*
 * LCD.c
 *
 *  Created on: Jul 19, 2025
 *      Author: Vishvajeet
 */


#include "stm32f1xx_hal.h"

#include "LCD.h"

#define RS_PIN GPIO_PIN_9
#define E_PIN GPIO_PIN_10

#define D1_PIN GPIO_PIN_1
#define D2_PIN GPIO_PIN_2
#define D3_PIN GPIO_PIN_3
#define D4_PIN GPIO_PIN_4
#define D5_PIN GPIO_PIN_5
#define D6_PIN GPIO_PIN_6
#define D7_PIN GPIO_PIN_7
#define D8_PIN GPIO_PIN_8

void LCD_Init()
{
	cmd(0x01);
	cmd(0x0E);
	cmd(0x06);
	cmd(0x38);
}

void cmd (int a)
{
	send_to_lcd(a, 0);
}

void data (char s)
{
	send_to_lcd(s, 1);
}
void send_to_lcd(char val, int rs)
{
	HAL_GPIO_WritePin(GPIOA, RS_PIN, rs);

	HAL_GPIO_WritePin(GPIOA, D1_PIN, val & 0x01);
	HAL_GPIO_WritePin(GPIOA, D2_PIN, val & 0x02);
	HAL_GPIO_WritePin(GPIOA, D3_PIN, val & 0x04);
	HAL_GPIO_WritePin(GPIOA, D4_PIN, val & 0x08);
	HAL_GPIO_WritePin(GPIOA, D5_PIN, val & 0x10);
	HAL_GPIO_WritePin(GPIOA, D6_PIN, val & 0x20);
	HAL_GPIO_WritePin(GPIOA, D7_PIN, val & 0x40);
	HAL_GPIO_WritePin(GPIOA, D8_PIN, val & 0x80);

	HAL_GPIO_WritePin(GPIOA, E_PIN, 1);
	HAL_Delay(10);
	HAL_GPIO_WritePin(GPIOA, E_PIN, 0);
}

void POS(int row, int col)
{
	switch(row)
	{
	case 1:
		col |= 0x80;
		break;

	case 2:
		col |= 0xc0;
		break;
	}
	cmd(col);
}


void string(char *s)
{
	while(*s)
		data(*s++);
}

void clear_screen()
{
	cmd(0x01);
}


