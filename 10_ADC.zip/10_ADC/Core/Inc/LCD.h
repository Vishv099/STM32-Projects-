/*
 * LCD.h
 *
 *      Author: Vishvajeet
 */

#ifndef INC_LCD_H_
#define INC_LCD_H_

void LCD_Init();
void cmd (int a);
void data (char s);
void send_to_lcd(char val, int rs);
void POS(int row, int col);
void string(char *s);
void clear_screen();

#endif /* INC_LCD_H_ */
