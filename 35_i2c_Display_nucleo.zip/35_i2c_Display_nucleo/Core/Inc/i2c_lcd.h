/*
 * i2c_lcd.h
 *
 *  Created on: Oct 6, 2025
 *      Author: Vishvajeet
 */

#ifndef INC_I2C_LCD_H_
#define INC_I2C_LCD_H_

#include "stm32f4xx_hal.h"

// Change this based on your LCD module address (usually 0x27 or 0x3F)
#define LCD_I2C_ADDRESS (0x27 << 1)

void lcd_init(I2C_HandleTypeDef *hi2c);
void lcd_send_cmd(char cmd);
void lcd_send_data(char data);
void lcd_send_string(char *str);
void lcd_put_cur(int row, int col);
void lcd_clear(void);



#endif /* INC_I2C_LCD_H_ */
