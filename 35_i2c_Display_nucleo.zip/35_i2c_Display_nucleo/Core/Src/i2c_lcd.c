#include "i2c_lcd.h"
#include "string.h"
#include "stdio.h"

static I2C_HandleTypeDef *_hi2c;

#define LCD_BACKLIGHT 0x08
#define ENABLE 0x04

static void lcd_send(uint8_t data, uint8_t rs)
{
    uint8_t data_u, data_l;
    uint8_t data_t[4];
    data_u = data & 0xF0;
    data_l = (data << 4) & 0xF0;
    data_t[0] = data_u | LCD_BACKLIGHT | rs | ENABLE;
    data_t[1] = data_u | LCD_BACKLIGHT | rs;
    data_t[2] = data_l | LCD_BACKLIGHT | rs | ENABLE;
    data_t[3] = data_l | LCD_BACKLIGHT | rs;
    HAL_I2C_Master_Transmit(_hi2c, LCD_I2C_ADDRESS, data_t, 4, 100);
}

void lcd_send_cmd(char cmd)
{
    lcd_send(cmd, 0);
}

void lcd_send_data(char data)
{
    lcd_send(data, 1);
}

void lcd_clear(void)
{
    lcd_send_cmd(0x01);
    HAL_Delay(2);
}

void lcd_put_cur(int row, int col)
{
    switch (row)
    {
    case 0:
        col |= 0x80;
        break;
    case 1:
        col |= 0xC0;
        break;
    }
    lcd_send_cmd(col);
}

void lcd_init(I2C_HandleTypeDef *hi2c)
{
    _hi2c = hi2c;
    HAL_Delay(50);
    lcd_send_cmd(0x30);
    HAL_Delay(5);
    lcd_send_cmd(0x30);
    HAL_Delay(1);
    lcd_send_cmd(0x30);
    HAL_Delay(10);
    lcd_send_cmd(0x20); // 4-bit mode
    HAL_Delay(10);

    lcd_send_cmd(0x28); // 2 line, 5x8 matrix
    lcd_send_cmd(0x08); // display off
    lcd_send_cmd(0x01); // clear display
    HAL_Delay(2);
    lcd_send_cmd(0x06); // entry mode set
    lcd_send_cmd(0x0C); // display on, cursor off
}

void lcd_send_string(char *str)
{
    while (*str) lcd_send_data(*str++);
}



